# par.yacc.py
# created: 2021-04-08, by jcr
# Parentesis language:
#       ()
#       (())
#       (())()((()))
#       ()()()()()
# --------------------------------
import ply.yacc as yacc
import sys

# Get the token map from the lexer.  This is required.
from parentesis_lex import tokens

# Production rules
#-----------------------------------------------------------
def p_parents(p):
     "parents : OPEN parents CLOSE parents"
     print("Reconheci uma frase: ", p[1], p[2], p[3], p[4])
                
def p_parents_empty(p):    
    "parents : "
    pass

 # Error rule for syntax errors
def p_error(p):
    print("Syntax error in input!")
#-----------------------------------------------------------
 
# Build the parser
parser = yacc.yacc()

# reading input
for linha in sys.stdin:
    result = parser.parse(linha)
    #print(result)

