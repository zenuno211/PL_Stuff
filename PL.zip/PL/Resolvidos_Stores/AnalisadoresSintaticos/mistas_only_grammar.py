
# Neste exercício pretende-se que defina formalmente uma linguagem para escrita
# de listas de elementos (um ou mais) escritos entre os símbolos '[' e '],
# em que cada elemento da lista pode ser uma palavra ou um número inteiro.

import sys
import ply.yacc as yacc

from mistas_lex import tokens


def p_grammar(p):
    """
    lista : LPAREN elementos RPAREN

    elementos : elementos VIRG elemento
              | elemento

    elemento : ID
             | NUM
    """


def p_error(p):
    print('Syntax error!')
    parser.success = False

parser = yacc.yacc()



for line in sys.stdin:
    parser.success = True
    parser.parse(line)

    if parser.success:
        print('Parsing successful!')

