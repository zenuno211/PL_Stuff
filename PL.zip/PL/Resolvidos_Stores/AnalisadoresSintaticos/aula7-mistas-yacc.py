import sys
import ply.yacc as yacc

from mistas_lex import tokens

def p_lista_vazia(p):
    "lista : LPAREN RPAREN"
    p.parser.elements = 0

def p_lista(p):
    "lista : LPAREN elementos RPAREN"
    pass


def p_elementos_virg(p):
    "elementos : elementos VIRG elemento"
    p.parser.elements += 1


def p_elementos_elemento(p):
    "elementos : elemento"
    p.parser.elements = 1


def p_elemento_id(p):
    "elemento : ID"
    p.parser.words.insert(0,p[1])


def p_elemento_num(p):
    "elemento : NUM"
    p.parser.numbers.append(p[1])
    p.parser.sum += p[1]



def p_error(p):
    print('Syntax error!')
    parser.success = False


parser = yacc.yacc()

for line in sys.stdin:
    parser.success = True
    parser.numbers = []
    parser.words = []
    parser.elements = 0
    parser.sum = 0

    parser.parse(line)

    if parser.success:
        print('Parsing completed!')
        print('Elements:', parser.elements)
        print('Numbers - quantity: ', len(parser.numbers), ' values: ', parser.numbers, ' sum: ', parser.sum)
        print('Words:', parser.words)
