import ply.lex as lex

tokens = (
    'LPAREN',
    'RPAREN',
    'VIRG',
    'ID',
    'NUM'
)

t_LPAREN = r'\['
t_RPAREN = r'\]'
t_VIRG   = r','
t_ID     = r'\w+'


def t_NUM(t):
    r'\d+'
    t.value = int(t.value)
    return t

t_ignore = ' \r\n\t'

def t_error(t):
    print('Illegal character: ' + t.value[0])


lexer = lex.lex()
