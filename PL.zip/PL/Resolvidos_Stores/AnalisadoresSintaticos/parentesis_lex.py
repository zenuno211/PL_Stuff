# par.lex.py
# created: 2021-04-08, by jcr
# Parentesis language:
#       ()
#       (())
#       (())()((()))
#       ()()()()()
# --------------------------------
import ply.lex as lex

# Tokens
tokens = ('OPEN', 'CLOSE')
t_OPEN = r'\('
t_CLOSE = r'\)'

t_ignore = " \t\n"

def t_error(t):
    print("Caráter ilegal: ", t.value[0])
    t.lexer.skip(1)

# build the lexer
lexer = lex.lex()
