import sys
import ply.yacc as yacc

from lista_compras_lex import tokens

def p_lisp_grammar(p):
    """
    lista : seccoes
    seccoes : seccoes seccao
    seccoes : 
    seccao : ID ':' produtos
    produtos : produto
    produtos : produtos produto
    produto : '-' codP SEP nomeP SEP precU SEP qt ';'
    codP  :  INT
    nomeP :  ID
    precU :  FLOAT
    qt    :  INT 
    """

def p_error(p):
    print('Syntax error!')

#inicio do Parser e do Processamento
parser = yacc.yacc()

parser.seccoes = set()
parser.produtos = dict()

#with open('lista_compras_exe.txt') as f:
#f = open('lista_compras_exe.txt')
#content = f.read()

content=""
for linha in sys.stdin:
    content += linha
parser.parse(content)
