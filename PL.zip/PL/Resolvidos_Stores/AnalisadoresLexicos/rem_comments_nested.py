import ply.lex as lex
import sys

states = [
    ('COMMENT', 'exclusive')
]

tokens = ['CBEGIN', 'CEND', 'CONTENT']

def t_ANY_CBEGIN(t):
    r'\/\*'
    t.lexer.push_state('COMMENT')
    #print('ENTREI NUM COMENTÁRIO')


def t_COMMENT_CEND(t):
    r'\*+\/'
    t.lexer.pop_state()
    #print('SAÍ DE UM COMENTÁRIO')


def t_COMMENT_CONTENT(t):
    r'(.|\n)'
    pass


def t_CONTENT(t):
    r'(.|\n)'
    print(t.value, end='')


def t_ANY_error(t):
    print('Illegal character: ' + t.value)


lexer = lex.lex()
for line in sys.stdin:
    lexer.input(line)
    for tok in lexer:
        pass
