import re
import sys

semaforo = False
soma = 0

for line in sys.stdin:
    l = re.findall(r'on|off|\d+|=', line)
    for e in l:
        if e == 'on':
            semaforo = True
        elif e == 'off':
            semaforo = False
        elif e == '=':
            print(soma)
        else:
            if semaforo:
                soma += int(e)
                
print("A soma calculada final e: ", soma)
