# ------------------------------------------------------------
# vending.py
#
# vending machine
# cc: 0, ligado, moeda
# ------------------------------------------------------------
import ply.lex as lex
import sys

# Declare the state
states = (
   ('ligado', 'exclusive'),
   ('moeda', 'exclusive')
)
 
# List of token names.   
tokens = (
    'ON',
    'OFF',
    'APROD',
    'BPROD'
)
 
# Rules for tokens in ANY state
# -------------------------------------
# Define a rule so we can track line numbers
def t_ANY_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)
 
# A string containing ignored characters (spaces and tabs)
t_ANY_ignore  = ' \t'
 
# Error handling rule: remaining chars
def t_ANY_error(t):
    t.lexer.skip(1)
    
# Rules for tokens in initial state
# -------------------------------------
def t_ON(t):
    r'[oO][nN]'
    print("Máquina ligada. Introduza o seu pedido:")
    t.lexer.begin('ligado')

# Rules for tokens in ligado state
# -------------------------------------
def t_ligado_OFF(t):
    r'[Oo][Ff][Ff]'
    print("A desligar... Recolha o seu troco: ", t.lexer.saldo)
    t.lexer.begin('INITIAL')

def t_ligado_MOEDA(t):
    r'(?i:moeda)'
    print("Pode introduzir moedas: ")
    t.lexer.begin('moeda')

def t_ligado_APROD(t):
    r'[aA]\d{1,2}'
    if(t.lexer.saldo >= 100):
        t.lexer.saldo = t.lexer.saldo - 100
        print("Comprou um produto do tipo A: ", t.value)
        print("O seu saldo é agora de :", t.lexer.saldo)
    else:
        print("Não tem saldo suficiente para adquirir este produto: ", t.value)
        print("O seu saldo é :", t.lexer.saldo)

def t_ligado_BPROD(t):
    r'[bB]\d{1,2}'
    if(t.lexer.saldo >= 50):
        t.lexer.saldo = t.lexer.saldo - 50
        print("Comprou um produto do tipo B: ", t.value)
        print("O seu saldo é agora de :", t.lexer.saldo)

def t_ligado_error(t):
    t.lexer.skip(1)

# Rules for tokens in moeda state
# -------------------------------------
# A string containing ignored characters (spaces and tabs)

def t_moeda_FMOEDA(t):
    r'\.'
    print('O seu saldo é :', t.lexer.saldo)
    print('Introduza o seu pedido: ')
    t.lexer.begin('ligado')

def t_moeda_C10(t):
    r'10c'
    t.lexer.saldo = t.lexer.saldo + 10

def t_moeda_C20(t):
    r'20c'
    t.lexer.saldo = t.lexer.saldo + 20

def t_moeda_C50(t):
    r'50c'
    t.lexer.saldo = t.lexer.saldo + 50

def t_moeda_E100(t):
    r'1e'
    t.lexer.saldo = t.lexer.saldo + 100

def t_moeda_E200(t):
    r'2e'
    t.lexer.saldo = t.lexer.saldo + 200

# =====================================
# Build the lexer
lexer = lex.lex()

# My state
lexer.saldo = 0
 
# Reading input
for linha in sys.stdin:
    lexer.input(linha) 
    tok = lexer.token()
    while tok:
        #print(tok)
        tok = lexer.token()

        
