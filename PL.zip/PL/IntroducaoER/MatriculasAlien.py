# -- Problema 4: Matr´ıculas de outro mundo
import re 

f = open("Matriculas.txt", "r")

print("««« Search »»»")

for linha in f:
  print(linha.strip()) #função strip parar tirar o \n da String linha
  y = re.search(r'^[0-9]{2}(\.\.\.|-|:)([0-9]{2}\1){2}[0-9]{2}$', linha)
  if y:
    print("Apanhei a matrícula")
  else:
    print("Não é uma matrícula de outro mundo!")

print("««« Search »»»")