import re

def busca(ER):
  fraseFonte = input(">> ")
  while fraseFonte != "":
    y = re.search(ER, fraseFonte)
    if(y): 
      print("Em \'", y.string, "\' foi encontrado: ", y.group())   
    else:
      print("Não encontrado")
    fraseFonte = input(">> ")

"""
e1 . e2
e1 + e2

e1^n = e1 . e1 . e1 ... n vezes

e1^+ -> e1 ocoree 1 ou mais vezes
e1^* -> e1 ocorre 0 ou mais vezes

12345

[0123456789]+ permite representar números de 0 a 9 uma ou mais vezes 

"""


#Todos os exercicios têm várias formas de se fazerem

# 1. 
def ex1():
  print("Linhas que contém algures a palavra 'padrão'")
  # busca(r'(?i:padrão)')
  busca(r'(?i:p)adrão')
  # busca(r'(P|p)adrão')
  # busca(r'[Pp]adrão')

  # Um exemplo diferente
  # busca(r'(pad|ma)rão')

# 2.
def ex2(): 
  print("Linhas que começam por 'PRH' ou 'JCR' ")
  busca(r'^(PRH|JCR)') # no inicio da linha (^)
  # busca(r'(PRH|JCR)$') # no fim da linha ($)

# 3.
def ex3(): 
  print("Linhas que começam por um Número")
  #busca(r'^[0123456789]+')
  busca(r'^[0-9]+')
  # se colocasse * em vez de + seria diferente pois encontrava sempre

# 4.
def ex4(): 
  print("Linhas que terminam com 'PMoura'")
  busca(r'PMoura$')

# 5.
def ex5(): 
  print("Linhas que terminam com: uma Letra (maíscula ou minúscula), ou com um ponto de interrogação, ou ponto final")
  busca(r'[a-zA-Z?.]$')
  # busca(r'(?i:[a-z?.])$')
  #(r'([a-z]|[A-Z]|[?]|[.])$')
  # busca(r'(?i:[a-z?.]|\?|\.)$')

# 6.
def ex6(): 
  print("Linhas que só contém digitos, hífens ou pontos")
  busca(r'^[0-9\-.]$')
  # busca(r'^[\-]|[0-9]|[.]$')

# 7.
def ex7(): 
  print("Linhas que começam por um ou mais Separadores de palavras (white spaces)")
  busca(r'^[' ']+')
  # busca(r'^[ \t]+')

# 8.
def ex8():
  print("Linhas que contém um número de telefone português (9 digitos)")
  busca(r'[0-9]{9}')
# 8a. permita que comece pelo indicativo do país
def ex8a():
  busca(r'9[0-9]{8}')

# 9.
def ex9(): 
  print("Linhas que contém uma STRING não nula entre aspas") # -> exemplo ola "pedro"
  busca (r'"[^"]*"') # representa exceto a " : por exemplo ("ola" eu "mundo "), dava o resultado ("ola" "mundo")

  # busca(r'".+?') # sem o ponto de interrogação tenta apanhar o máximo possível : por exemplo ("ola" eu "mundo "), dava o resultado ("ola" eu "mundo ") em vez de só ("ola" "mundo")

  # busca(r'.+') # -> o ponto representa todos os caracteres pelo que esta expressão aceita tudo

# 9a. repita o exercício anterior permitindo Strings vazias
# 9.b repita o exercício anterior escrevendo apenas o texto entre aspas


# 10
def ex10():
  print("A phone number. This is three digits followed by a dash followed by four digits.")
  busca (r'[0-9]{3}[\-][0-9]{4}') 

# 11. This time your phone number should not have an area code - only the three digit, dash, four digit local phone number. (You can assume that your phone number is preceded by a whitespace character.)

# 12. Last, allow your phone number to be seven consecutive digits as well as the three digit dash four digit type.
def ex12():
  print("Both ex10 an ex11 ways:")
  busca(r'([0-9]{3}[\-][0-9]{4})|([0-9]{7})')

def extra():
  print("Linhas que contêm um ou uma")
  busca(r'uma?') # o a pode ou não aparecer