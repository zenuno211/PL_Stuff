import re
# output only the lines with the following characteristics:
# 1. that contains the word hello anywhere on the line

print("1b. Linhas que encontram várias ocorrências da palavra: hello")

inputFromUser = input(">> ")
while inputFromUser != "":
  y = re.findall(r'(?i:hello)', inputFromUser)
  #?i: para procurar palavras tenham eles letras maisculas ou minusculas
  # função findall para descobrir todas as ocorrencias de uma string 
  if(y): 
    print(inputFromUser)
    print("Encontradas ", len(y), " ocorrencias: ")
    print(y)   
  else:
    print("hello não encontrado")
  inputFromUser = input(">> ")
