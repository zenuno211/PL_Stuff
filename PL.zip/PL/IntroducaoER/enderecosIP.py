# -- Problema 2: Endereços IP
import re 

f = open("enderecos.txt", "r")

print("««« Search »»»")

for linha in f:
  print(linha.strip())
  # y = re.search(r'^([0-9]{1,3}(\.)[0-9]{1,3}(\.)[0-9]{1,3}(\.)[0-9]{1,3})$', linha) 
  y = re.search(r'^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])$', linha) 
  if y:
    print("este é um endereço IPV4!")
  else:
    # j = re.search(r'^([0-9a-z]{4}(\:)[0-9a-z]{4}(\:)[0-9a-z]{4}(\:)[0-9a-z]{4}(\:)[0-9a-z]{4}(\:)[0-9a-z]{4}(\:)[0-9a-z]{4}(\:)[0-9a-z]{4})$', linha)
    j = re.search(r'^([0-9a-f]{1,4}(:)){7}[0-9a-f]{1,4}$',linha)
    if j:
        print("este é um endereço IPV6!")
    else:
        print("Erro")   

print("««« Search »»»")
