# -- Problema 3: Latitude e Longitude 
import re 

f = open("LatitudeLongitude.txt", "r")

print("««« Search »»»")

for linha in f:
  print(linha.strip()) #função strip parar tirar o \n da String linha
  y = re.search(r'^((+|-)([0-9]|[1-9][0-9]|90)), ((+|-)([0-9]|[1-9][0-9]|1[0-7][0-9]|180))$', linha) 
  if y:
    print("Válido")
  else:
    print("Inválido")
print("««« Search »»»")