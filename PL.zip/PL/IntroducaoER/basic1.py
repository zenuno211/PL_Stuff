import re
# output only the lines with the following characteristics:
# 1. that contains the word hello anywhere on the line

print("1. Linhas que contêm a palavra: hello")
inputFromUser = input(">> ")
while inputFromUser != "":
  y = re.search(r'hello', inputFromUser)
  if(y): 
    #print(y)
    print("Encontrada: ", y.group(), " em: ", y.string()) 
    # função group() retorna a palavra procurada e encontrada
    # a função string() retorna a string onde se faz a procura 
    (ini,fim)=y.span()
    # a função span() retorna uma tupla contendo as posições (inicial, final) da string combinada
    comp = fim-ini # nº de caracteres
    print("na posição ", y.span()," com carateres ",comp)  
  else:
    print("hello não encontrado")
  inputFromUser = input(">> ")
