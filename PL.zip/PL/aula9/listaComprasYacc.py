import ply.yacc as yacc

from listaCompras import tokens

def p_grammar(p):
    """
    lista : categoria
    categorias : categoria categorias
               |categoria

    categoria : nomeCat '[' Produtos ']'

    nomeCat : ID

    produtos : produto produtos
             |produto
    
    produto: '-' INT ',' STR ',' REAL ',' INT
    """

    def p_error(p):
        print("Syntax error")
    
    parser = yacc.yacc()

    f=open("exemplo.txt")
