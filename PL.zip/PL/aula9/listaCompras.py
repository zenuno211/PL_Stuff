'''
Lista Compras

-> Está dividida em secções/categorias
-> Cada categoria tem uma lista de produtos
-> Cada produto tem:
    -um código
    -um nome
    -um preço
    -quantidade



(exemplo)

CARNE[
    -1,"panado de porco",6.46,2
]
ENLATADOS[
    -2,"Salsichas",1.99,4
]
BEBIDAS[
    -3,"Coca-cola",1.00,2
    -4,"Água",0.40,1
]



(Gramática)

LISTA COMPRAS
lista: categoria
categorias: categoria categorias
           |categoria
categoria: nomeCat '[' Produtos ']'
nomeCat: ID
produtos: produto produtos
         |produto
produto: '-' INT ',' STR ',' REAL ',' INT


'''


import ply.lex as lex 


tokens = [
    'INT'
    'REAL'
    'STR'
    'ID'
]

literais = ['[',']','-',',']

def t_REAL(p):
    r'\d+\.\d+'
    t.value = float(t.value)
    return t

def t_INT(p):
    r'\d+'
    t.value = int(t.value)
    return t

(meter como os outros)
t_ID = r'\w+'

def t_STR(p):
    r'\"[^\"]\"'
    t.value = t.value[1:-1]
    return t

t_ignore = ' \n\t'

def t_error(t):
    print("Illegal character", t.value[0])
    t.lexer.skip(1)

lexer = lex.lex()

f = open("exemplo.txt")

for token in f:
    print(token)