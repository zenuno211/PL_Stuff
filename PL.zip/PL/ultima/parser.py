""" 
lisp : SExp

SExp : pal
    | num
    | ( SExplist )
SExpList : 
    | SExp SExpList


 """

def next_Symbol():
    global ps
    ps = lexer.token()
    if ps:
        ps = ps.type
    ps = ps.type


def rec_lisp():
    if ps in {'PAL','NUM','('}:
        rec_sexp()
    else:
        print('erro a reconhecer List')
        exit(1)

def rec_sexp():
    if ps in {'PAL'}:
        rec_PAL()
    elif ps in {'NUM'}:
        rec_NUM()
    elif ps in {'('}:
        rec_PE()
        rec_explist()
        rec_PD()
    else:
        print('erro ao conhecer uma SExp')
        exit(2)

def rec_sexplist():
    if ps in {')'}:
        pass
    if ps in {'PAL','NUM','('}:
        rec_exp()
        rec_sexplist()
    else:
        print('Erro ao conhecer uma SExpList')
        exit(3)

def rec_NUM():
    if ps == 'NUM':
        next_Symbol()
    else:
        print('Erro Num')
        exit(4)

def rec_PAL():
    if ps == 'PAL':
        next_Symbol()
    else:
        print('Erro PAL')
        exit(5)

def rec_PE():
    if ps == '(':
        next_Symbol()
    else:
        print('Erro (')
        exit(6)

def rec_PD():
    if ps == ')':
        next_Symbol()
    else:
        print('Erro )')
        exit(7)


import sys
from lisp_lex import lexer

for line in sys.stdin:
    lexer.input(line)
    next_Symbol()
    rec_lisp()