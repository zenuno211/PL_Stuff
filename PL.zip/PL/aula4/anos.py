# Em 2020, a cˆamara de Braga tornou gratuito o exame a atletas do sexo feminino. Quantos atletas do sexo
# feminino realizaram exame em 2020? E em cada um dos outros anos?

import re

f = open ('emd.csv')
next(f) # funciona como um iterador, logo assim vai avançar para a próxima linha (neste caso linha 2)

anos = {}
for line in f:
    
    campos = re.split(r',', line.strip()) # existe também o rstrip e o l strip que remove os caracteres invisiveis à direita e esquerda de uma string
    
    if campos[6]=='F':
        data = campos[2]
        ano = re.split(r'-', data)[0]

        if ano in anos.keys():
            anos[ano]+=1
        else: 
            anos[ano]=1

sorted_anos = dict (sorted(anos.items(), key=lambda par: par[0])) #ordenado pela key ou seja o ano
# sorted_anos = dict (sorted(anos.items(), key=lambda par: par[1])) #ordenado pelo value ou seja o numero de raparigas
print(sorted_anos)

f.close()