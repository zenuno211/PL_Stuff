# • Produz uma listagem dos atletas que praticam atletismo ordenada pela idade;
import re

with open('emd.csv') as f: #não é preciso fazer fclose porque ele já fecha o ficheiro
    next(f)

    atletas =[]
    for line in f:
        campos = re.split(r',',line)
        modalidade = campos[-5]

        if modalidade == 'Atletismo':
            [primeiro, ultimo] = campos[3:5]
            idade = campos[5]

            nome_completo = primeiro + ' ' + ultimo
            atletas.append(nome_completo,int(idade))
    
    atletas.sort(key=lambda p: (p[1],p[0])) #ordena por p[1] mas no caso de estes serem iguais ordena por p[0]
    print(atletas)