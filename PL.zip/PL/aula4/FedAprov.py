# Dos atletas que realizaram exame, quantos s˜ao federados? E quantos foram aprovados no exame?

import re

f = open ('emd.csv')
next(f) # funciona como um iterador, logo assim vai avançar para a próxima linha (neste caso linha 2)

d = {'F': 0, 'A': 0}
for line in f:
    
    campos = re.split(r',', line.strip()) # existe também o rstrip e o l strip que remove os caracteres invisiveis à direita e esquerda de uma string
    
    #fed = campos[-2] 
    #aprov = campos[-1]
    [fed,aprov]= campos[-2:]

    if fed == 'true':
        d['F'] +=1
    if aprov == 'true':
        d['A'] +=1

print("Federados:",d['F'])
print("Aprovados:",d['A'])

f.close()