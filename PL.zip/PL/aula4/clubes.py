# Produz uma lista ordenada alfabeticamente dos clubes desportivos registados, no fim indica quantos sao;

import re

#l = [1,2,3,4]
#l[0:2] = [1,2,3]
#l[0:3:2] = [1,3]
#l[::2] = [1,3]
#l[1::2] = [2,4]

f = open ('emd.csv')
next(f) # funciona como um iterador, logo assim vai avançar para a próxima linha (neste caso linha 2)

# clubes = [] #pode ter repetições
clubes = set() # não tem repetições 
for line in enumerate(f):
    
    campos = re.split(r',', line[1])
    clube = campos[-4] # quarto elemento a contar do fim
    
    clubes.add(clube)

clubes = list(clubes) #Num set não interessa a ordem mas numa lista sim
clubes.sort()
print("Lista: ",clubes)
print("Número de clubes: ", len(clubes))

f.close()