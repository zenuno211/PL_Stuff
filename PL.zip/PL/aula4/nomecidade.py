#Produz uma listagem apenas com o primeiro e ´ultimo nome do atleta e a cidade onde vive;
#-------------------------------------------------------------------------------------------
import re


f = open ('emd.csv')
next(f) # funciona como um iterador, logo assim vai avançar para a próxima linha (neste caso linha 2)

for line in enumerate(f):
    """
    m = search(r'^(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)$')
    if m:
        primeiro = m.group(4)
        ultimo = m.group(5)
        cidade = m.group(8)

    printf(f'Nome: {primeiro} {ultimo} Cidade: {cidade}')
    """

    #ou ignorando a primeira linha
    """
    i = line[0]

    if i==0:
        continue
    """

    campos = re.split(r',', line[1])
    primeiro = campos[3]
    ultimo = campos[4]
    cidade = campos[7]
    
    print(f'Nome: {primeiro} {ultimo} Cidade: {cidade}')

f.close()