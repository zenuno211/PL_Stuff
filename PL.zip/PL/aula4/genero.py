# • Qual a distribui¸c˜ao de atletas registados por sexo?

import re

f = open ('emd.csv')
next(f) # funciona como um iterador, logo assim vai avançar para a próxima linha (neste caso linha 2)

d = {'M': 0, 'F': 0}
for line in enumerate(f):
    
    campos = re.split(r',', line[1])
    genero = campos[6] 
    d[genero]+=1 # se for F -> d['F']+=1, se for M -> d['M']+=1 

print("Feminino:",d['F'])
print("Masculino:",d['M'])

f.close()