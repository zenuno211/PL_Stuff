#Produz uma listagem das modalidades ordenada alfabeticamente e, para cada uma, indica quantos atletas
#realizaram exame;

import re

with open('emd.csv') as f: #não é preciso fazer fclose porque ele já fecha o ficheiro
    next(f)

    modalidade = {}
    for line in f:
        campos = re.split(r',',line)
        m = campos[8]

        if m in modalidade:
            modalidade[m]+=1
        else:
            modalidade[m]=1
        
        
        
    
    modalidade.sort(key=lambda p: p[0])
    print(modalidade,len(modalidade))