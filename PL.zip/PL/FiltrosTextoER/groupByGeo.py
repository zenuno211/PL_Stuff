# Group by campo 2
# Para fins didáticos vou usar dicionários/arrays associativos em Python
import re

res = {}

f = open("arqson.txt",encoding="utf-8")
for linha in f:
    campos = re.split(r'::', linha)
    if(campos[1] in res):
        res[campos[1]] = res[campos[1]] + 1
    else:
        res[campos[1]] = 1   

# Escrita ordenada alfabeticamente pelo valor da chave
for regiao in sorted (res): 
    #print ((regiao, res[regiao]), end =" ") 
    print ((regiao, res[regiao])) 
    

