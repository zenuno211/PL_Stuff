import re
#comentário multi-linha
"""
re.search
re.match
re.findall
re.finditer

re.sub
"""

#string multi-linha
text = """
<livro id='134' ano='1998'>
    <titulo>Sermão</titulo>
</livro>"""


match = re.search(r'<livro\s+id=\'([^\']+)\'\s+ano=\'([^\']+)\'', text)
print("match = " + match.group(0))
print("grupos = " + str(match.groups())) #print("grupos = ", match.groups())
print("id = " + match.group(1))
print("ano = " + match.group(2))


def n_occor(r, text):
    return len(re.findall(r, text))

print(n_occor(r'titulo', text))



"""
def upper_group(m: re.Match) -> str:
    return m.group(1).upper()


p = re.search(r'([0-9]+) ([a-z]+) ([0-9]+)', text)


print(type(p))
print(p.group(3))

new_text = re.sub(r'([a-z]+)', upper_group, text)
print(new_text)
"""
