# Quais os títulos das músicas que têm "Jesus" e quantas são
import re

jesus = []

f = open("arqson.txt",encoding="utf-8")

for linha in f:
    campos = re.split(r'::', linha)
    teste = re.search(r'(?i:jesus)', campos[2])
    if (teste): 
        jesus.append(campos[2])
        
jesus.sort()
#print(jesus)
for cancao in jesus:
   print(cancao)
print("Encontrei ", len(jesus), " músicas com \"Jesus\" no título")

