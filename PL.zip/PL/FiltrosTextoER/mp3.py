# Quais os títulos das músicas alentejanas
import re

mp3 = []

f = open("arqson.txt",encoding="utf-8")

for linha in f:
    teste = re.search(r'\.mp3', linha)
    if (teste): 
        campos = re.split(r'::', linha)
        mp3.append(campos[2])
        
mp3.sort()
print(mp3)

