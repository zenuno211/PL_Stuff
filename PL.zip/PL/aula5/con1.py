import re


f = open('relatorio.xml')
content = f.read()

content = re.sub(r'<\?xml version=".+" enconding"(.+)"\?>', r'<!DOCTYPE html>\n<htlm>\n<head>\n<meta charset="\1">\n</head>',content)

content = re.sub(r'<realtorio>',r'<body>',content)

content = re.sub(r'(</?)titulo>',r'\1h1>',content)

content = re.sub(r'<data>',r'<h2>',content)

content = re.sub(r'<Autores>',r'<h3>Autores<h3>\n<ul>',content)

content = re.sub(r'<autor>',r'<ul>',content)



print(content)


f.close()