import ply.yacc as yacc

from lmistas_lex import tokens #não sabe o que é este import

def p_inv_funcao(p):
    "inv_funcao : ID lista_mista"
    print("Parsing completed!")
    p[0] = p[2]

def p_lista_mista(p):
    "lista_mista : PE conteudo PD"
    p[0] = p[2]

def p_conteudo_empty(p):
    "Conteudo: "
    p[0]=[]

def p_conteudo_elementos(p):
    "conteudo: elementos"
    p[0]=p[1]

def p_elementos_elemento(p):
    "elementos: elemento"
    p[0] = [p[1]]

def p_elementos_virg(p):
    "elemtos: elementos VIRG elementos"
    p[0] = [p[1]] + p[3]
    # p[0] = p[3] + [p[1]] assim invertia a linha imprimida

def p_elemento_ID(p):
    "elemnto: ID"
    p[0]=p[1]


def p_error(p):
    print("Syntax erro!")



parser = yacc.yacc()
parser.pal = 0
parser.num = 0
parser.soma = 0
parser.lista = []


import sys

for line in sys.stdin:
    parser.parse(line)
    parser.pal = 0
    parser.soma = 0