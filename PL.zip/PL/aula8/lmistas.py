import ply.lex as lex


tokens = [
    'NUM',
    'ID',
    'PE',
    'PD',
    'VIRG',
]

t_ID = r'\w+'
t_PE = r'\('
t_PD = r'\)'
t_VIRG = r','

def t_NUM(t):
    r'\d+'
    t.vlaue = int(t.vlaue)
    return t

t_ignore = ' \n\t'

def t_error(t):
    print('Illegal character:' + t.value[0])
    t.lexer.skip(1)


lexer = lex.lex()

import ply.yacc as yacc

def p_grammar(p):
    """
    lista_mista : PE elementos PD
                | PE PD

    elementos: elemento
             | elemento VIRG elementos

    elemento: ID  
            | NUM
    """    
    pass

def p_error(p):
    print('Syntax error!')
    parser.succes = False

parser = yacc.yacc()



import sys


for line in sys.stdin:
    parser.success = True
    parser.parse(line)
    if parser.success:
        print('Parsing completed!')