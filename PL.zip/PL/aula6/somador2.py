import re
import sys

flag = False
soma = 0

for line in sys.stdin:
    
    elementos = re.findall(r'on|off|\d+|=',line)
    print(elementos)

    for e in elementos:
        if e == 'on':
            flag = True
        if e == 'off':
            flag = False
        if e == '=':
            print('Soma atual:', soma)
        else:
            if flag:
                soma+=int(e)

print('Soma Total',soma)
