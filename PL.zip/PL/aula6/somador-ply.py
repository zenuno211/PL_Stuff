import ply.lex as lex

# ER -> Ação

#Lista de tokens.Obrigatória defenir
tokens = [
    'ON',
    'OFF',
    'EQUAL',
    'NUMBER',
]

flag = False
soma = 0
linhas = 1

def t_ON(t):
    r'[oO][Nn]'
    global flag  #temos de utiliazar global para alterar a varivel global  
    flag = True
    print('Soma ativada!')
    return t

def t_OFF(t):
    r'(?i:off)'
    global flag
    flag = False
    print('Soma desativada!')
    return t

def t_EQUAL(t):
    r'='
    print('Soma Atual', soma)
    return t

def t_NUMBER(t):
    r'\d+'
    t.value = int(t.value)
    if flag:
        global soma
        soma += int(t.value)
    return t

def t_error(t):
    print('Erro no caracter:', t.value)


def t_spaceIgnore(t):
    r'\ '
    pass

def t_newline(t):
    r'\n'
    global linhas
    linhas+=1

data = 'on 1 2 3 = off 2 2 =on 2 2 ='

lexer = lex.lex()

lexer.input(data)

while True:
    token = lexer.token()
    if not token:
        break

print('Soma total:',soma)
print(linhas)