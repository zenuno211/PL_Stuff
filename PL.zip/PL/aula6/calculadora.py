"""
1
a
1.2 +1
1 * 2 + 1.01 / 4
a * b +1 
"""


import ply.lex as lex
import sys

tokens = [
    'INT'
    'FLOAT'
    #'PLUS'
    #'MUL'
    #'SUB'
    #'DIV'
    'ID'
]

literals = ['\+', '\*', '-', '/']


def t_FLOAT(t):
    r'd+\.\d+'
    return t

def t_INT(t):
    r'\d+'
    return t

def t_error(t):
    print('Error in character:', t.value[0])
    t.lexer.skip(1)

lexer = lex.lex8
for line in sys.stdin:
    lexer.input(line)
    for token in lexer:
        print(token)

    """
    while true:
        token = lexer.token()
        if not token:
            break
        print(token)
    """


"""
t_ID = r'\w+'
#def t_ID(t):
#    r'\w+'
#    return t

t_PLUS = r'\+'
#def t_PPLUS(t):
#    r'\+'
#    return t

t_SUB = r'-'
#def t_SUB(t):
#    r'-'
#    return t

t_MUL = r'\*'
#def t_MUL(t):
#    r'*'
#    return t

t_DIV = r'/'
#def t_DIV(t):
#    r'/'
#     return t
"""
