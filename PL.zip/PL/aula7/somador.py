import ply.lex as lex
import sys


tokens = ['ON','OFF','EQUAL','NUMBER']

#contextos
states = [
    ('soma', 'exclusive')
]


def t_NUMBER(t):
    r'\d+'
    pass

def t_ON(T):
    r'(?i:on')
    t.lexer.begin('soma') # mudar para o contexto soma
    print('SOMA ATIVADA')

'''
def t_EQUAL(t):
    r'='
    print('Soma atual:',t.lexer.soma)

#não faz sentido defenir o off uma vez que ele não aparece num contexto inicial

def t_ignore = ' \n\t'

def t_error(t):
    print('Illegal character: ' + t.value[0])
    t.lexer.skip(1) #limpar o programa
'''
#--------------------------------------------------------------

def t_soma_NUMBER(t):
    r'\d+'
    t.lexer.soma += int(t.value)

def t_soma_OFF(t):
    r'(?i:off)'
    t.lexer.begin('INITIAL') #mudar para o contexto INITIAL
    print('SOMA DESATIVADA')

def t_ANY_EQUAL(t):
    r'='
    print('Soma atual:',t.lexer.soma)

def t_ANY_ignore = ' \n\t' #ANY define a regra para todos os contextos existentes

def t_ANY_error(t):
    print('Illegal character: ' + t.value[0])
    t.lexer.skip(1) #limpar o programa

lexer = lex.lex()

lexer.soma = 0

for line in sys.stdin:
    lexer.input(line)
    for token in lexer:
        pass






