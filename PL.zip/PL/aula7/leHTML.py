import ply.lex as lex

import sys



tokens = ['BOLD','ITALIC','UNDERLINE','SECTION','SUBSECTION','SUBSUBSECTION','ENUMERATE','ITEMIZE','ITEM','TEXTO']

states = [

    ('bold', 'inclusive'), # podia ser inclusive. No exclusive so tao ativas as regras definidas
    ('italic', 'inclusive'),
    ('underline', 'inclusive'),
    ('section', 'inclusive'),
    ('subsection', 'inclusive'),
    ('subsubsection', 'inclusive'),
    ('enumerate', 'inclusive'),
    ('itemize', 'inclusive'),
    ('item', 'inclusive'),
    ('texto', inclusive)
]


def t_BOLD(t):
    r'\\textbf{'
    print('<b>', end='')
    t.lexer.push_state('bold')

def t_BOLD_end(t):
    r'\}'
    print('<b>', end='')
    t.lexer.pop_state()

def t_ITALIC(t):
    r'\\textit{'
    print('<i>', end='')
    t.lexer.push_state('bold')

def t_BOLD_end(t):
    r'\}'
    print('<i>', end='')
    t.lexer.pop_state()

def t_ITALIC(t):
    r'\\underline{'
    print('<u>', end='')
    t.lexer.push_state('bold')

def t_BOLD_end(t):
    r'\}'
    print('<u>', end='')
    t.lexer.pop_state()

(...)

#acabar, ver gravação 6/5/2021