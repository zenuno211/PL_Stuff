import ply.lex as lex

import sys



tokens = ['ON','OFF','COMMENT','NOTCMT']



states = [

    ('comentario', 'exclusive') # podia ser inclusive. No exclusive so tao ativas as regras definidas

]



#contexto initial







def t_ANY_ON(t):

    r'/\*'

    t.lexer.push_state('comentario')

    print('Começou comentário')



def t_NOTCMT(t):

    r'(.|\s)'

    t.lexer.comentario+=t.value



def t_ANY_error(t):

    print('Illegal character at some state: ' + t.value[0])

    t.lexer.skip(1)



def t_comentario_OFF(t):

    r'\*/'

    t.lexer.pop_state()

    print('Acabou comentário')



def t_comentario_COMMENT(t):

    r'(.|\s)'



lexer = lex.lex()



lexer.comentario = ''



f = open('comments.txt')



g = open('output.txt','w')



for line in f:

    lexer.input(line)

    for tok in lexer:

        pass

    

g.write(lexer.comentario)