import re

f = open("text.txt",encoding="utf-8")
for linha in f:
    if (re.search(r'!!!', linha)):
        print(re.search(r'!!!', linha))
        aLer = print("Fim")
    elif(re.search(r'(dia|DIA)', linha)):
        print(re.search(r'(dia|DIA)', linha))
        aLer = print(1)
    elif(re.search(r'[Dd][Ii][Aa]', linha)):
        print(re.search(r'[Dd][Ii][Aa]', linha))
        aLer = print(2)
    elif(re.search(r'[dia|DIA]', linha)):
        print(re.search(r'[dia|DIA]', linha))
        aLer = print(3)
    elif(re.search(r'dia{1,3}', linha)):
        print(re.search(r'dia{1,3}', linha))
        aLer = print(4)


#Respsota: O outpu seria "211131"!!