// 1 + 2 

//pushi 1
//pushi 2
//ADD

//1 + 2 * 3

//pushi 1
///pushi 2
//pushi 3
//mul
//add

//1 - 2 * 3 / (2 + 1)

//pushi 1
//pushi 2
//pushi 3
//mul
//pushi 2
//pushi 1
//add
//div
//sub

//1 < 2 

//pushi 1
//pushi 2
//inf

// 1.0 + 4.5

//pushf 1.0
//pushf 4.5
//Fadd

// 1 + 4.5
//pushi 1
//itof
//pushf 4.5
//fadd

//int("1")

//pushs "i"
//atoi

//str(1)

//pushi 1
//stri

//print("ola")

//pushs "ola"
//writes

//print(1)

//puhsi 1
//writei

//write(read())

//read
//writes

//write(read(int))

//read
//atoi
//writei

//a=5
//1+a 

//pushi 5
//pushi 1
//pushg 0
//add

//a = 4 e b = 7
//a+b

//pushi 4
//pushi 7

//pushg 0
//pushg 1

//add

//a = 5
//a = a + 1

//pushi 5
//pushg 0
//pushi 1
//add
//storeg 0


//

//int a = 0;
//int b = 2;
//int n;
//n = 5 * b
//repeat n : a = a + 1
//print(a)

//declarações
pushi 0
pushi 2
pushi 0

start 

// n = 5 * b
pushi 5
pushg 1
mul
storeg 2

//ciclo
repeat:

    // caso de paragem pata n = 0
    pushg 2
    jz end
    
    //a = a + 1
    pushg 0
    pushi 1
    add
    storeg 0    

    //n = n - 1
    pushg 2
    pushi 1
    sub
    storeg 2

    //voltar a fazer o ciclo
    jump repeat

end:
    pushg 0
    writei




